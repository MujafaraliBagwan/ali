﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace EmployeeManagment
{
    public partial class EmpData : Form
    {
        SqlConnection con;SqlCommand cmd;SqlParameter p;
        public EmpData()
        {
            InitializeComponent();

        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

           
        }

        private void txtEname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtDesig_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtEname_KeyPress(sender, e);
        }

        private void doj_EnabledChanged(object sender, EventArgs e)
        {
           // doj.MaxDate = DateTime.Now;
        }

        private void txtsal_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtId_KeyPress(sender, e);
        }

        private void EmpData_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Server=; User id=sa;Password=123;Database=employee;");
                      
        }
        protected void Clear()
        {
           foreach(Control c in Controls)
            {
                if(c is TextBox)
                {
                    c.Text = "";
                }
            }
        }
       
        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (txtId.Text == "")
            {
                MessageBox.Show("please enter employee id");
                txtId.Focus();
            }
            else if (txtEname.Text == "")
            {
                MessageBox.Show("please enter employee name");
                txtEname.Focus();
            }
            else if (txtDesig.Text == "")
            {
                MessageBox.Show("please enter employee Designation");
                txtDesig.Focus();
            }
            else if (txtsal.Text == "")
            {
                MessageBox.Show("please enter employee salary");
                txtsal.Focus();
            }
            else if (txtDno.Text == "")
            {
                MessageBox.Show("please enter employee Department Number");
                txtsal.Focus();
            }
            else
            {

                try
                {
                    cmd = new SqlCommand("InsertEmp", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    p = new SqlParameter("@eid", SqlDbType.Int);
                    p.Value = txtId.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@ename", SqlDbType.VarChar, 50);
                    p.Value = txtEname.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@desig", SqlDbType.VarChar, 50);
                    p.Value = txtDesig.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@doj", SqlDbType.DateTime);
                    p.Value = doj.Value;
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@salary", SqlDbType.Money);
                    p.Value = txtsal.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@dno", SqlDbType.VarChar, 10);
                    p.Value = txtDno.Text.Trim();
                    cmd.Parameters.Add(p);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("record inserted sucessfully");
                    Clear();
                    doj.Text = "";
                    btnFind_Click(sender, e);
                }
                catch (Exception e1)
                {
                    MessageBox.Show(""+e1.Message);
                }
            }
        }

       
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(txtId.Text=="")
            {
                MessageBox.Show("enter employee id");
                txtId.Focus();

            }
            else
            {
                try
                {
                    cmd = new SqlCommand("DeleteEmp", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    p = new SqlParameter("@eid", txtId.Text.Trim());
                    cmd.Parameters.Add(p);
                    
                    DialogResult dr = MessageBox.Show(this,"Do you want to delete the employee ?", "Message", MessageBoxButtons.YesNoCancel);
                    if(dr.Equals(DialogResult.Yes))
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("employee deleted sucessfully");
                        txtId.Text = "";
                        btnFind_Click(sender, e);
                    }
                    else
                    {
                        MessageBox.Show("employee not deleted from database");
                    }
                }
                catch (Exception e1)
                {
                    MessageBox.Show("" + e1.Message);
                }
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = new SqlCommand("DispEmp", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "emp");
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch(Exception e1)
            {
                MessageBox.Show("" + e1.Message);
            }

        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
            if (txtId.Text == "")
            {
                MessageBox.Show("please enter employee id");
                txtId.Focus();
            }
            else if (txtEname.Text == "")
            {
                MessageBox.Show("please enter employee name");
                txtEname.Focus();
            }
            else if (txtDesig.Text == "")
            {
                MessageBox.Show("please enter employee Designation");
                txtDesig.Focus();
            }
            else if (txtsal.Text == "")
            {
                MessageBox.Show("please enter employee salary");
                txtsal.Focus();
            }
            else if (txtDno.Text == "")
            {
                MessageBox.Show("please enter employee Department Number");
                txtsal.Focus();
            }
            else
            {

                try
                {
                    cmd = new SqlCommand("UpdateEmp", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    p = new SqlParameter("@eid", SqlDbType.Int);
                    p.Value = txtId.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@ename", SqlDbType.VarChar, 50);
                    p.Value = txtEname.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@desig", SqlDbType.VarChar, 50);
                    p.Value = txtDesig.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@doj", SqlDbType.DateTime);
                    p.Value = doj.Value;
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@salary", SqlDbType.Money);
                    p.Value = txtsal.Text.Trim();
                    cmd.Parameters.Add(p);

                    p = new SqlParameter("@dno", SqlDbType.VarChar, 10);
                    p.Value = txtDno.Text.Trim();
                    cmd.Parameters.Add(p);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("record Updated sucessfully");
                    Clear();
                    doj.Text = "";
                    btnFind_Click(sender, e);
                }
                catch (Exception e1)
                {
                    MessageBox.Show("" + e1.Message);
                }
            }
        }
    }
}

